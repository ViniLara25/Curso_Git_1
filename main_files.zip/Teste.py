print ("Hello world")# Curso_Git_1

aluno = input ("Digite seu nome ")
print ("Seu nome é:", aluno)